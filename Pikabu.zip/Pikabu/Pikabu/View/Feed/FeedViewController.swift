//
//  FeedViewController.swift
//  Pikabu
//
//  Created by Aleksey Bardin on 26.11.2020.
//

import UIKit

class FeedViewController: UIViewController {
    
    // MARK: - Outlet

    @IBOutlet private var feedTableView: UITableView! {
        willSet {
            newValue.register(nibCell: TableViewCell.self)
            newValue.tableFooterView = UIView()
        }
    }

    var postStorage = PostStorage.shared

    // MARK: - Private property

    private var viewModel: TableViewViewModelType?

    // MARK: - LifeCicle

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.title = Text.feedTitle

        setupViewModel()
        addPostLocalStorage()
        removePostLocalStorage()
    }

    func addPostLocalStorage() {

        viewModel?.onAddedStorage = { [weak self] post in
            guard let post = post else {return }

            self?.postStorage.localPosts.append(post)
        }
    }

    func removePostLocalStorage() {
        viewModel?.onRemovedStorage = { [weak self] post in

            guard
                let self = self,
                let post = post,
                let index = self.postStorage.localPosts.firstIndex(where: { (removePost) -> Bool in
                    removePost == post
                })
            else {
                return
            }

            self.postStorage.removePost(index)
        }
    }
}

// MARK: - UITableViewDataSource

extension FeedViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel?.numberOfRows() ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeue(reusable: TableViewCell.self, for: indexPath)

        guard let viewModel = viewModel else { return cell }
        var post = viewModel.cellViewModel(forIndexPath: indexPath)


        cell.onAddedStorage = { [weak self] _ in
            post?.isFavorite = true
            self?.viewModel?.pushPostDataLocalStorage(post)

        }

        cell.onRemovedStorage = { [weak self] _ in
            post?.isFavorite = false
            self?.viewModel?.popPostDataLocalStorage(post)
        }

        cell.setupPost(post)

        return cell
    }
}

extension FeedViewController {
    func setupViewModel() {
        viewModel = FeedViewModel()
        viewModel?.fetchAllPosts { [weak self] in
            DispatchQueue.main.async {
                self?.feedTableView.reloadData()
            }
        }
    }
}
